---
title: 'README'
metaTitle: 'README'
metaDesc: 'README'
socialImage: ''
data: '2024-Sep-01 10:08'
tag: 
        - csharp
---

# README

Go to bootstrap website and find CDN of bootstrap

Go to cdnjs search for "font-awesome"

Ctrl+Shift+P => Simple Browser => http://localhost:5500


container

d-flex


